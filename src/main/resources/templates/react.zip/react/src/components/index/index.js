import React from 'react'
import ReactDOM from 'react-dom'
import 'whatwg-fetch'
import axios from 'axios'
import './style.css'

class UserList extends React.Component {
  constructor(props){
    super(props);
    this.state = {users: []};
  }
  
  componentDidMount() {
    axios.get('/users', {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json'
      }
    })
    .then(response => {
      this.setState({users: response.data._embedded.users})
    })
  }
  
  render() {
      var data = { a: 1, b: 2 };
    return(
      <div><pre>{JSON.stringify(data) }</pre>
      <li to="/sso/logout">Home</li>
      </div>
    )
  }
}

ReactDOM.render(
  <UserList />,
  document.getElementById('root')
)