const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const CleanWebpackPlugin = require('clean-webpack-plugin');

module.exports = {
  entry: {
    app: './src/components/index/index.js',
  },
  // track down errors and warnings
  devtool: 'eval-source-map', 
  /* This tells webpack-dev-server to serve the files from the dist directory on localhost:8080
   * provides you with a simple web server and the ability to use live reloading
   */
  devServer: {
    contentBase: path.resolve(__dirname, '../dist'),
    compress: true,
    port: 9000,
    clientLogLevel: "none",
    inline: true,
    proxy: {
      "/": "http://localhost:8080/"
    }
  },
  output: {
    filename: '[name].bundle.js',
    path: path.resolve(__dirname, '../dist'),
    publicPath: '/'
  },
  resolve: {
    extensions: ['.js', '.jsx', '.css']
  },

  module: {
    rules: [
      {
        test: /\.(js|jsx)$/,
        exclude: /node_modules/,
        loader: 'babel-loader',
        query: {
          presets: ['react', 'es2015', 'stage-0'],
          plugins: ['transform-runtime']
        }
      },
      {
        test: /\.css$/,
        use: [
            'style-loader',
            'css-loader'
        ]
      },
      {
        test: /\.(png|svg|jpg|gif)$/,
        use: [
          'file-loader'
        ]
      },
      {
        test: /\.(csv|tsv)$/,
        use: [
          'csv-loader'
        ]
      },
      {
        test: /\.xml$/,
        use: [
          'xml-loader'
        ]
      }
    ]
  },
  
  plugins: [
    // clean dist directory
    // new CleanWebpackPlugin(['../dist']),
    // create new index.html, if exist, will be overwrite
    new HtmlWebpackPlugin({
      title: 'Output Management',
      template: 'index.ejs'
    })
  ]
  
};