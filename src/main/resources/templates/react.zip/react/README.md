# setup
node version: v6.11.2

# build
npm run build

# run with single webpack.config.js
npm run start

# webpack-dev-middleware
npm run server
